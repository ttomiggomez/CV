


function clicked(){


if($('#message').css('display') === 'none'){
  $('#message').css('display','block');
} else {
  $('#message').css('display','none');
}



  
  }
